import "@/list.css"
import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router'

const List = () => {

    // 0. 데이터 배열
    const list = [
        { title : "아이템1", content : "내용", accept : 1},
        { title : "아이템2", content : "설명", accept : 2},
    ]

    // 1. Hook 선언
    const navigate = useNavigate() // 페이지 이동
    
    // 2. 상태 선언
    const [arrs, setArrs] = useState([]) // 화면에 보여줄 '필터링된 리스트' 상태 초기화 (빈 배열)
    const [state, setState] = useState(0) // 현재 선택된 필터 카테고리 상태 초기화(0), 0: 전체, 1: 승인, 2: 미승인
    
    // 3. 이벤트(버튼 클릭, i : 아이템)
        // 아이템 클릭 시 해당 아이템의 인덱스(i) 번호로 상세 페이지 경로 변경
    const onclick = i => navigate('/detail/'+i) // `/detail/${i}`

    // 4. 필터링 → [state : 필터 카테고리]가 변경될 때마다 실행
    useEffect(()=>{
        if(state === 1 || state === 2) { // [조건문] : 만약 state(버튼 선택 상태)가 1(승인) '또는' 2(미승인)인 경우
            // 원본 List에서 accept 값이 state랑 똑같은 것만 골라서 arrs 상태에 저장ㄱㄱ(setArrs)
            setArrs(list.filter(row => row.accept === state))
        } else { // [예외] state가 0(전체)이거나 그 외라면?
            setArrs([...list])
            // 원본 List 전체를 복사해서 arrs 상태에 저장ㄱㄱ
        }
    }, [state]) // state 값이 바뀔 때마다 감지함 -> useEffect 로직 재실행 => 화면 갱신

    /*
        ※ 흐름도
            1. 초기화
                : 컴포넌트가 로드되면 useEffect가 실행되서 arrs 상태에 전체 리스트가 담김
            2. 이벤트 발생
                : 사용자가 '승인' 버튼을 클릭
            3. 상태 변경
                : setState(1)이 호출되서 state가 1이 됨
            4. 반응 처리
                : state가 변했으니까 useEffect가 다시 실행됨
                : list.filter를 통해 accept === 1인 데이터만 setArrs에 담김
            5. 화면 갱신(UI)
                : arrs가 변했으니까 화면 하단의 arrs?.map 부분이 다시 그려짐
                : '승인' 아이템만 나타남
    */

    /* 
        ※ 동작 시나리오
            1. '승인' 버튼 클릭 
                : setState(1) 실행 → state가 1이 됨
            2. useEffect 감지 
                : state가 변했으니 리액트가 "어?변했네?로직 실행해야겠다" 하고 useEffect 내부를 실행
            3. 필터 실행
                : state가 1이므로 list.filter(row => row.accept === 1)이 작동 → 조건에 맞는 것만 생존
            4. 화면 갱신
                : 승인된 데이터만 담긴 새로운 배열이 arrs에 저장 → 화면에는 승인 항목만 보임
    */

    /*
        ※ filter()
            : 조건에 맞는 데이터만 골라내서 새로운 배열을 만드는 함수
            : 즉, 원본은 건드리지 않고 원하는 것만 쏙쏙 뽑아낸 '복사본'을 만든다
            
            row : 배열 안의 객체 하나하나를 의미(임의로 정함)
            row.accept === 1 : 이 조건이 true인 데이터만 남김
    */

    /* 
        ※ [...list]
            : setArrs(list)라고 써도 될 것 같지만 리액트에서 스프레드 연산자[...list]를 쓰는 권장 관습이 있음(얼탱;)
            : 리액트는 '기존 배열의 주소'가 바뀌어야 데이터가 변했다고 인식함
            : 기존의 상태(state)를 그대로 복사하면서 특정 값만 수정할 때 사용
            : 배열이나 객체 안에 있는 내용물을 하나씩 펼쳐서(Spread) 새로운 바구니에 옮겨 담는다
            : [...]은 원본과 똑같이 생겼지만 '완전히 새로운 주소를 가진 새 배열'을 만드는 행위
            : 위와 같은 행위가 있어야 리액트가 "우왕, 새로운 배열 들어왔네 화면 새로 그려야겠군"하고 확실히 인지
    */

  return (
    <div className="container mt-3">
        <h1 className="text-center bg-success text-dark bg-opacity-50">LIST</h1>

        {/* 필터링 버튼 & 추가 버튼 영역 */}
        <div className="d-grid gap-2 d-md-flex justify-content-md-end">
            <button className="btn btn-secondary" type="button" 
                    onClick={()=>setState(0)} >전체</button>
            <button className="btn btn-success" type="button"
                    onClick={()=>setState(1)} >승인</button>
            <button className="btn btn-warning" type="button"
                    onClick={()=>setState(2)} >미승인</button>

            <a href="/new" className="btn btn-primary">추가</a>
                {/* a태그 사용으로 페이지 새로고침 */}
        </div>

        {/* 가공된 데이터(arrs) 화면 출력 영역 */}
        <div className="list-group mt-2 text-center">
            {   // arrs 배열의 각 요소(v)와 인덱스(i)를 순회하며 버튼 생성
                // arrs?
                    // : 안전장치, 만약 arrs가 null이나 undefined일 경우 에러 말고 조용히 넘어가게 해줌
                    // : 에러가 나면 앱이 멈추는데, ?를 붙여서 "데이터가 있으면 map 돌리고, 없으면 에러 말고 걍 기다리셈"
                arrs?.map((v, i)=>
                    <button key={i} // 리스트 항목을 식별하기 위한 고유 키값
                            className={`list-group-item m-1 display-6 ${v.accept === 1 ? "list-group-item-success" : "list-group-item-warning"}`}
                                // 데이터의 accept 값에 따라 Bootstrap 클래스를 다르게 적용 -> 배경색 바꿈
                            onClick={()=>onclick(i)}>
                                {/* 버튼 클릭하면 해당 아이템의 인덱스(i)를 가지고 상세 페이지 이동 */}
                        {v.title}
                            {/* 데이터의 제목을 버튼 텍스트로 표시  */}
                    </button>
                )
            }

            {/* 
                ※ map()
                    map은 데이터를 하나하나 꺼내서 '다른 형태(태그)로 변환'
                    - 원본 : [{title: "아이템1", ...}, {title: "아이템2"...}] (데이터 객체 배열)
                    - 변신 : [<button>아이템1</button>, <button>아이템1</button>] (리액트 배열)

                    (v, i) : 매개변수
                        - v(value) : 배열 안의 데이터 한 덩어리 ({title: "아이템1", accept: 1})
                        - i(index) : 배열의 순번
                    
                    key={i}
                        - 리액트가 리스트를 렌더링할 때, 각 항목이 서로 다른 것임을 식별하기 위한 이름표
                        -  이게 없으면 리액트가 "어떤 버튼이 수정된거징?"하고 헷갈려서 경고 메세지 띄움
                    
                    ${v.accept === 1 ? "..." : "..."}
                        - 데이터(v)안에 들어있는 accept 값을 확인
                        - 1 이면 : 성공 색상(초록색) 클래스 입히기
                        - 1 아니면 : 경고 색상(노란색) 클래스를 입힘
                        - ∴ 승인된 데이터는 초록색, 미승인 데이터는 노란색
                    
                    onClick={()=> onclick(i)}
                        - 버튼을 누르면 onclick 함수에 현재 아이템의 번호(i)를 담아서 보냄
                        - 그러면 /detail/0 같은 주소로 이동하게 됨
            */}
        </div>
    </div>
  )
}

export default List