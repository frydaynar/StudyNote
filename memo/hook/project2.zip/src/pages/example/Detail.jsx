import { useState, useEffect } from 'react'
import { useParams, useNavigate } from 'react-router'

const Detail = () => {

    // params => 배열의 index가 주소창에 뜸(위치)
    const list = [
        { title : "아이템1", content : "내용", accept : 1 },
        { title : "아이템2", content : "설명", accept : 2 },
    ]

    // 1. Hook 설정
    const params = useParams() // URL의 파라미터(/detail/:id)를 가져온다
    const navigate = useNavigate()
    
    // 2. 상태(State) 관리
    const [title, setTitle] = useState("")
    const [content, setContent] = useState("")
    const [accept, setAccept] = useState(0)

    // 현재 '읽기 전용' 상태인지 여부 (true: 읽기전용)
    // 즉, true(읽기전용) 상태일때 -> 수정불가(readonly) / false(수정가능) 상태일때 -> 수정가능(onChange)
    const [isEdit, setIsEdit] = useState(true) 

    // 3. 공통 함수
    const close = () => navigate("/") // close() 호출시 List 페이지 이동

    // 4. 폼 제출 (저장하기)
    const onSubmit = e => {
        e.preventDefault() // 새로고침 방지
        if(!isEdit) return // 수정 모드가 아닐 때 실행하지 않겠어 (반대로 보일 수 있으나 버튼 클릭하면 상태 바뀜)
        const data = {title, content, accept}
        console.log(data)
    }

    // 5. 초기 데이터 로딩?
    useEffect(()=>{
        const data = list[params.id] // URL 파라미터로 받은 id(인덱스)로 데이터 검색 -> App.jsx 같이 보셈 (/detail/:id)
            /*
                - params.id를 통해 이전 List 페이지에서 넘겨준 인덱스 값을 받아옴
                - 이 값을 이용해 list[params.id] 처럼 배열의 특정 데이터를 찾아 화면에 뿌려줌
            */

        if(data === undefined) return close() // 데이터 없으면 강제로 메인 이동

        // 가져온 데이터를 상태에 저장 -> 화면에 표시
        setTitle(data?.title)
        setContent(data?.content)
        setAccept(data?.accept)
    }, [])

    // useEffect(() => {
    //     console.log("현재 isEdit 상태가 변경되었습니다:", isEdit);
    // }, [isEdit]);

    // useEffect(() => {
    //     console.log("현재 accept 상태가 변경되었습니다:", accept);
    // }, [accept]);

  return (
    <div className="container mt-3">
        <h1 className="text-center bg-success text-dark bg-opacity-50">DETAIL</h1>
        <form onSubmit={onSubmit}>
            <div className="mb-3 mt-3">
              <label htmlFor="title" className="form-label">Title:</label>
              <input type="text" className="form-control" id="title" 
                        placeholder="Enter title" name="title"
                        // readOnly 속성이 isEdit값에 따라 결정됨 (true : 수정불가, false : 수정 가능)
                        required autoComplete="off" readOnly={isEdit}
                        value={title} onChange={e=>setTitle(e.target.value)} />
            </div>
            <div className="mb-3">
              <label htmlFor="content" className="form-label">Content:</label>
              <input type="text" className="form-control" id="content" 
                    placeholder="Enter content" name="content" 
                    autoComplete="off" readOnly={isEdit}
                        value={content} onChange={e=>setContent(e.target.value)} />
            </div>
            <div className="d-grid gap-2 d-md-flex justify-content-md-end">

                {/* 
                    - [수정/저장] 버튼 : 클릭 시 isEdit 상태를 반전시킴
                    - 버튼 텍스트 : {isEdit ? "수정" : "저장"}
                    - 즉, 사용자가 '수정' 버튼을 누르기 전까지 내용을 고칠 수 없게 만들어줌
                    
                */}
                
                <button className="btn btn-primary me-md-2" type="submit"
                        onClick={()=>setIsEdit(!isEdit)}> {isEdit ? "수정" : "저장"} </button>
                {/* <!-- 승인 & 미승인 교차 하여 화면 표현 하시오. --> */}
                {/* 
                    - [승인/미승인] 버튼 : accept 상태에 따라 버튼의 색상과 텍스트가 조건부 렌더링
                    - 승인 버튼 : (accept === 1) ? <미승인버튼> : <승인버튼>
                */}
                {
                    (accept === 1) ?
                    <button className="btn btn-warning" type="button"
                            onClick={()=>setAccept(2)}> 미승인 </button> :
                    <button className="btn btn-success" type="button"
                            onClick={()=>setAccept(1)}> 승인 </button>
                }

                {/* =================================== */}
                {/* 
                    1. onSubmit 함수 안에 if(!isEdit) return 구문이 있음
                    2. 사용자가 '수정' 버튼을 누르면 setIsEdit(!isEdit)에 의해 isEdit가 false가 됨 => 수정 가능
                    3. 이후 내용을 고치고 다시 버튼('저장'버튼으로 보이는 중)을 누르면 onSubmit이 실행
                    4. 이때 setIsEdit가 다시 호출되서 isEdit가 true로 바뀌면서 데이터가 출력
                    ※ 주의 ※
                        accept 상태를 바꾸는 버튼(승인/미승인)은 눌러도 isEdit 상태와 상관없이 즉시 반영됨
                */}
                {/* =================================== */}

                <button className="btn btn-secondary" onClick={close}> 취소 </button>
            </div>
        </form>
    </div>
  )
}

export default Detail