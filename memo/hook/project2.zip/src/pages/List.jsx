import "@/list.css"
import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router'

const List = () => {

    const list = [
        { title : "아이템1", content : "내용", accept : 1 },
        { title : "아이템2", content : "설명", accept : 2 },
    ]

    const navigate = useNavigate()

    const [arrs, setArrs] = useState([])
    const [state, setState] = useState(0)

    const onclick = i => navigate(`/detail/${i}`)

    useEffect(()=>{
        if(state === 1 || state === 2) {
            setArrs(list.filter(row => row.accept === state))
        } else {
            setArrs([...list])
        }
    }, [state])

    return (
        <div className="container mt-3">
        <h1 className="text-center bg-success text-dark bg-opacity-50">LIST</h1>
            <div className="d-grid gap-2 d-md-flex justify-content-md-end">
                <button href="#" className="btn btn-secondary" onClick={()=>setState(0)}>전체</button>
                <button href="?accept=1" className="btn btn-success" onClick={()=>setState(1)}>승인</button>
                <button href="?accept=0" className="btn btn-warning" onClick={()=>setState(2)}>미승인</button>
                <a href="/new" className="btn btn-primary">추가</a>
            </div>
            <div className="list-group mt-2 text-center">
                {
                    arrs?.map((v, i) => 
                        <button key={i} 
                                className={`list-group-item m-1 display-6 ${v.accept === 1 ? "list-group-item-success" : "list-group-item-warning"}`}
                                onClick={()=>onclick(i)}> {v.title} 
                        </button>
                    )
                }
            </div>
        </div>
    )
}

export default List