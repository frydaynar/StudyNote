import { useState } from 'react'

// project1 : 삭제 힌트
// 가운데 줄 긋는거 : project3 (true, false)
// push, filter(삭제할때) 해야함
// 검색 부분 : 미승인,승인

const Page = () => {

    const [word, setWord] = useState("")

    const add = e => {
        e.preventDefault()
        const data = {word}
        console.log(data)
    }

    return (
    <div className="word-container">
        <h3 className="text-center mb-4">단어장</h3>

        {/* <!-- 입력 및 수정 영역 --> */}
        <form className="input-group mb-3" onSubmit={add}>
            <input type="text" name="word" className="form-control" 
                    placeholder="단어를 입력하세요" required 
                    value={word} onChange={e=>setWord(e.target.value)}/>
            <button type="submit" className="btn btn-primary">추가</button>
        </form>

        {/* <!-- 검색 영역 --> */}
        <input type="text" name="search" className="form-control mb-3" 
            placeholder="검색어를 입력하세요" onKeyUp={()=>{}} />

        {/* <!-- 목록 --> */}
        <ul className="list-group">
        {/* <!-- 단어를 여기에 추가됩니다 --> */}
        <li className="list-group-item d-flex justify-content-between align-items-center word-item">
            <div className="form-check">
            <input className="form-check-input" type="checkbox" onChange={()=>{}} />
            <span className="ms-2">반복문 정리하기</span>
            </div>
            <button className="btn btn-sm btn-outline-danger" onClick={()=>{}}>삭제</button>
        </li>
        <li className="list-group-item d-flex justify-content-between align-items-center word-item completed">
            <div className="form-check">
            <input className="form-check-input" type="checkbox" onChange={()=>{}} checked />
            <span className="ms-2">조건문 정리완료</span>
            </div>
            <button className="btn btn-sm btn-outline-danger" onClick={()=>{}}>삭제</button>
        </li>
        </ul>
    </div>
    )
}

export default Page