import { useNavigate } from 'react-router'

const List = () => {

  // table 클릭시 각각 select 페이지로 이동하기 위해 사용
  // select 페이지로 보내기 위해
  const navigate = useNavigate();

  // 클릭이 발생하면 select페이지(상세페이지)로 넘어갈때
  // data(스티븐과 에브릴 정보)를 보내줌
  const onclick = (data) => {
    // navigate('보내는 페이지(주소)', {정보})
    // index.jsx에 이미 주소값을 넣어놈 <Route path='/detail' element={<Select />} />
    // navigate가 일종의 매개체 => 저 주소로 찾아갈거임, data를 가지고
    navigate('detail', {state:data})
  }

  // tbody 배열 생성
  // "key":1 -> 그냥 관리용, 페이지를 각각 하나씩 넘기기 위해 넣은 정보
  const arr = [
    {"key":1, "name":"스티븐", "email":"jobs@shellfolder.com", "regDate":"2023-02-28", "pwd":"1234", "gender":true},
    {"key":2, "name":"에브릴", "email":"lavigne@shellfolder.com", "regDate":"2023-02-27", "pwd":"5678", "gender":false}
  ]

  // tbody의 tr cursor 효과 (손가락 모양)
  const styles = {
    "cursor":"pointer"
  }

  return (
      <div className="container mt-3">
        <h1 className="display-1 text-center">사용자 목록</h1>
        <div className="btn-group">
          <a href="Create.html" className="btn btn-primary">사용자 추가</a>
        </div>
        <table className="table table-hover mt-3">
          <thead className="table-dark">
            <tr>
              <th>이름</th>
              <th>이메일</th>
              <th>가입날짜</th>
            </tr>
          </thead>
          <tbody>
            {
              arr.map((v, i) => {
                return (
                  // onclick 발생하면 value 값이 data값(주소값)으로 들어가서 같이 넘어감
                  // key는 고유값, index만큼 반복시키기. arr의 "key"와는 상관이 없음
                  <tr style={styles} onClick={()=>onclick(v)} key={i}>
                    <td> {v.name} </td>
                    <td> {v.email} </td>
                    <td> {v.regDate} </td>
                  </tr>
                )
              })
            }
          </tbody>
	      </table>
	    </div>
  )

}

export default List