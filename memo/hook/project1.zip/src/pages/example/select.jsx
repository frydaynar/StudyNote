// useState : 데이터 저장 및 변경 (기억 장치 -> 기억하고 있다가 바뀜)
// useEffect : 특정 시점에 코드 실행 (특정 상황에 발동하는 알람)
// useNavigate : 페이지 이동 시키기 (운전기사 -> 목적지로 이동)
// useLocation : 현재 위치 정보 가져오기 (현재 주소판 -> 여기가 어디인지 확인)

import { useState, useEffect } from 'react'
import { useNavigate, useLocation } from 'react-router'

const Select = () => {

  const navigate = useNavigate()
  const location = useLocation()

  // 버튼 클릭하면 사용자목록(List) 페이지로 이동하기 위한 함수
  const onclick = () => navigate("/")
  
  // data라는 상태값, setData라는 상태값 업데이트 함수 = useState(초기값, 현재 data정보)
  const [data, setData] = useState({name:"", email:"", pwd:"", gender:true})

  // 예외처리 (특정 시점에 코드 실행)
  useEffect(()=>{
    if(location.state === null) { // location.state(= 현재 위치정보 : List 페이지의 data(onclick(v)) ) null값일때
      return onclick() // onclick 함수 실행 (=> list 페이지로 이동)
    }
    // setData가 업데이트시 loction.state 보여주기
    setData(location.state) 
  }, [] ) // [] : 빈 배열이면 컴포넌트가 처음 나타날때 딱 한 번만 실행
  console.log(data) 


  return (
    <div className="container mt-3">
	  <h1 className="display-1 text-center">사용자 정보</h1>
		<form>
		  <div className="mb-3 mt-3">
		    <label htmlFor="name" className="form-label">이름:</label>
		    <input type="text" className="form-control" id="name" placeholder="이름을 입력하세요." name="name" readOnly="readonly" defaultValue={data.name} />
		  </div>
		  <div className="mb-3 mt-3">
		    <label htmlFor="email" className="form-label">이메일:</label>
		    <input type="email" className="form-control" id="email" placeholder="이메일를 입력하세요." name="email" readOnly="readonly" defaultValue={data.email} />
		  </div>
		  <div className="mb-3">
		    <label htmlFor="pwd" className="form-label">비밀번호:</label>
		    <input type="password" className="form-control" id="pwd" placeholder="비밀번호를 입력하세요." name="pwd" readOnly="readonly" defaultValue={data.pwd} />
		  </div>
			<div className="d-flex">
			  <div className="p-2 flex-fill">
			  	<div className="form-check">
					<input type="radio" className="form-check-input" id="radio1" name="gender" value="1" checked={data.gender === true} readOnly="readonly" />남성
					<label className="form-check-label" htmlFor="radio1"></label>
				</div>
			  </div>
			  <div className="p-2 flex-fill">
			  	<div className="form-check">
          {/* checked : 보여주는 용도, readOnly : 이벤트임(radio랑 같이가는), readonly나 onchange 둘 중 하나는 반드시 있어야 함, defaltValue를 넣을건지 onchange를 넣을건지 */}
					<input type="radio" className="form-check-input" id="radio2" name="gender" value="2" checked={data.gender === false} readOnly="readonly" />여성
					<label className="form-check-label" htmlFor="radio2"></label>
				</div>
			  </div>
			</div>
		</form>
		<div className="d-flex">
		  <div className="p-2 flex-fill d-grid">
		  	<a href="Update.html" className="btn btn-primary">수정</a>
		  </div>
		  <div className="p-2 flex-fill d-grid">
				<a href="List.html" className="btn btn-primary">삭제</a>
		  </div>
		  <div className="p-2 flex-fill d-grid">
			<button className="btn btn-primary" onClick={onclick}>취소</button>
		  </div>
		</div>
	</div>
        
  )
}

export default Select